use eframe::{egui, App};
use futures_util::StreamExt;
use reqwest::Client;
use std::fs::{self, File};
use std::io::Write;
use std::path::Path;
use std::process::Command;
use std::sync::{Arc, Mutex};
use tokio::runtime::Runtime;

struct MyApp {
    prompt_input: String,
    output: Arc<Mutex<String>>,
    running: Arc<Mutex<bool>>,
    rt: Runtime,
}

impl Default for MyApp {
    fn default() -> Self {
        Self {
            prompt_input: String::new(),
            output: Arc::new(Mutex::new(String::new())),
            running: Arc::new(Mutex::new(false)),
            rt: Runtime::new().unwrap(),
        }
    }
}

impl App for MyApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        ctx.set_visuals(egui::Visuals::dark());

        let output = self.output.clone();
        let running = self.running.clone();

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("🚀 Rust CLI GUI with Streaming Output");
            ui.label("Enter a prompt below and watch live output:");

            // Input Prompt
            egui::Frame::group(ui.style()).show(ui, |ui| {
                ui.horizontal(|ui| {
                    ui.label("📝 Prompt:");
                    ui.add(
                        egui::TextEdit::singleline(&mut self.prompt_input)
                            .hint_text("Type your prompt here...")
                            .desired_width(f32::INFINITY),
                    );
                });
            });

            ui.separator();

            // Action Button
            let is_running = *running.lock().unwrap();

            if is_running {
                ui.horizontal(|ui| {
                    ui.spinner();
                    ui.label("Running...");
                });
            } else {
                if ui.button("▶️ Run Prompt").clicked() && !is_running {
                    {
                        let mut running_lock = running.lock().unwrap();
                        *running_lock = true;
                    }
                    {
                        let mut output_lock = output.lock().unwrap();
                        output_lock.clear();
                    }

                    let prompt = self.prompt_input.clone();
                    let output_clone = output.clone();
                    let running_clone = running.clone();
                    let ctx_clone = ctx.clone();

                    self.rt.spawn(async move {
                        let result = run_cli_logic(prompt, output_clone.clone(), ctx_clone.clone()).await;

                        let mut output_lock = output_clone.lock().unwrap();
                        if let Err(err) = result {
                            output_lock.push_str(&format!("\n❌ Error: {}", err));
                        }

                        *running_clone.lock().unwrap() = false;
                        ctx_clone.request_repaint();
                    });
                }
            }

            ui.separator();

            // Output Display
            ui.label("📤 Output:");
            egui::ScrollArea::vertical()
                .auto_shrink([false; 2])
                .show(ui, |ui| {
                    let output_text = output.lock().unwrap().clone();
                    ui.add(
                        egui::TextEdit::multiline(&mut output_text.clone())
                            .font(egui::TextStyle::Monospace)
                            .desired_rows(20)
                            .desired_width(f32::INFINITY),
                    );
                });

            // Copy button
            if ui.button("📋 Copy Output").clicked() {
                ctx.output_mut(|o| o.copied_text = output.lock().unwrap().clone());
            }

            ui.separator();
            ui.label("💡 Built with egui + Rust | © 2025");
        });
    }
}

async fn run_cli_logic(
    prompt: String,
    output: Arc<Mutex<String>>,
    ctx: egui::Context,
) -> Result<(), Box<dyn std::error::Error>> {
    let backend_url = "http://localhost:3000";
    let zip_filename = "dummy.zip";
    let client = Client::new();

    // 1. Send prompt
    let res = client
        .post(format!("{}/prompt", backend_url))
        .json(&serde_json::json!({ "prompt": prompt }))
        .send()
        .await?;

    if !res.status().is_success() {
        return Err(format!("Prompt failed: {:?}", res.status()).into());
    }

    // 2. Stream response
    let mut stream = client
        .get(format!("{}/prompt-stream", backend_url))
        .send()
        .await?
        .bytes_stream();

    while let Some(Ok(chunk)) = stream.next().await {
        let text = String::from_utf8_lossy(&chunk);

        let cleaned_lines = text
            .lines()
            .filter_map(|line| {
                let line = line.trim();
                if line.starts_with("data:") {
                    let trimmed = line.trim_start_matches("data:").trim();
                    if trimmed == "__DOWNLOAD__" {
                        None
                    } else {
                        Some(trimmed)
                    }
                } else {
                    None
                }
            })
            .collect::<Vec<_>>();

        let cleaned_text = cleaned_lines.join(" ");

        if !cleaned_text.is_empty() {
            let mut out = output.lock().unwrap();
            if !out.is_empty() {
                out.push(' ');
            }
            out.push_str(&cleaned_text);
        }

        ctx.request_repaint();

        if text.contains("__DOWNLOAD__") {
            break;
        }
    }

    // 3. Download ZIP
    let mut zip_res = client.get(format!("{}/download-zip", backend_url)).send().await?;
    let mut file = File::create(zip_filename)?;
    while let Some(chunk) = zip_res.chunk().await? {
        file.write_all(&chunk)?;
    }

    // 4. Run Python script to extract
    let status = Command::new("python3")
        .arg("openzip.py")
        .arg(zip_filename)
        .status()?;

    if !status.success() {
        return Err("Python script failed.".into());
    }

    // 5. Write to dummy project
    let dummy_folder = Path::new("dummy");
    let src_folder = dummy_folder.join("src");
    let main_rs_path = src_folder.join("main.rs");
    let cargo_toml_path = dummy_folder.join("Cargo.toml");

    if !dummy_folder.exists() {
        return Err("Extracted folder 'dummy' not found.".into());
    }

    fs::create_dir_all(&src_folder)?;
    let output_text = {
        let out_lock = output.lock().unwrap();
        out_lock.clone()
    };
    fs::write(&main_rs_path, output_text)?;

    let cargo_toml_content = r#"[package]
name = "dummy_project"
version = "0.1.0"
edition = "2021"

[dependencies]
"#;
    fs::write(&cargo_toml_path, cargo_toml_content)?;

    // 6. Open in VSCode
    let status = Command::new("code").arg(&main_rs_path).status()?;
    if !status.success() {
        return Err("Failed to open VSCode.".into());
    }

    Ok(())
}

fn main() {
    let mut options = eframe::NativeOptions::default();
    options.default_theme = eframe::Theme::Dark;
    eframe::run_native("🚀 Rust CLI GUI", options, Box::new(|_cc| Box::new(MyApp::default())));
}

